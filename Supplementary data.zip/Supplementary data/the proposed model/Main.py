import pandas as pd
from GetData import get_mape, get_mse
from Model import LSTM
from itertools import chain
import torch
import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm
from Config import Config
from GetData import nn_seq
from loss.dilate_loss import dilate_loss
import time
import psutil
import os


# 
process = psutil.Process(os.getpid())


#torch.manual_seed(123) 
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
config = Config()
Dtr, Dte, m, n = nn_seq(config)
model = LSTM(config.feature_size, config.hidden_size, config.num_layers, config.output_size).to(device)

def train(model, config, Dtr):
    optimizer = torch.optim.Adam(model.parameters(), lr=config.learning_rate)
    print('training...')
    epochs = config.epochs
    for epoch in tqdm(range(epochs)):
        train_loss, train_shape, train_temporal = [], [], []
        for batch_idx, (seq, target) in enumerate(Dtr, 0):
            seq, target = seq.to(device), target.to(device)
            optimizer.zero_grad()
            y_pred = model(seq)
            y_pred, target = y_pred.unsqueeze(dim=2).to(device), target.unsqueeze(dim=2).to(device)
            loss, loss_shape, loss_temporal = dilate_loss(y_pred, target, config.alpha, config.gamma, device)
            train_loss.append(loss.item())
            train_shape.append(loss_shape.item())
            train_temporal.append(loss_temporal.item())
            loss.backward()
            optimizer.step()

        print('epoch {:03d} train_loss {:.6f} train_shape {:.6f} train_temporal {:.6f}'.format(epoch+1, np.mean(train_loss), np.mean(train_shape), np.mean(train_temporal)))
        model.train()

def test(model, config, Dte, m, n):
    model.eval()
    pred = []
    y = []
    for batch_idx, (seq, target) in enumerate(Dte, 0):
        seq = seq.to(device)
        with torch.no_grad():
            target = list(chain.from_iterable(target.tolist()))
            y.extend(target)
            y_pred = model(seq)
            y_pred = list(chain.from_iterable(y_pred.data.tolist()))
            pred.extend(y_pred)

    y, pred = np.array(y), np.array(pred)

    y = (m - n) * y + n
    pred = (m - n) * pred + n
    print('mse:', get_mse(y, pred))
    print('mape:', get_mape(y, pred))
    
    
    plt.plot(y, c='green', label='true')
    plt.plot(pred, c='red', label='pred')
    plt.grid(axis='y')
    plt.legend()
    plt.show()
    print(y.shape)
    print(pred.shape)
    y, pred = pd.DataFrame(y), pd.DataFrame(pred)
#    y.to_excel('TureCarbonFuture.xlsx',index=False)
#    pred.to_excel('PredCarbonFuture.xlsx',index=False)
    


