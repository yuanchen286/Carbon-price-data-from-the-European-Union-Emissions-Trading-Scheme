import torch.nn as nn

#LSTM
class LSTM(nn.Module):
    def __init__(self, feature_size, hidden_size, num_layers, output_size):
        super(LSTM, self).__init__() 
        self.hidden_size = hidden_size  
        self.num_layers = num_layers  
        
        
        self.lstm1 = nn.LSTM(feature_size, hidden_size, num_layers, batch_first=True)
#        self.lstm2 = nn.LSTM(hidden_size[0], hidden_size[1], num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_size, output_size)
        # 
        self.relu = nn.ReLU()

    def forward(self, x):
#        batch_size = x.shape[0]  
#        if hidden is None:
#            h_0 = x.data.new(self.num_layers, batch_size, self.hidden_size).fill_(0).float()
#            c_0 = x.data.new(self.num_layers, batch_size, self.hidden_size).fill_(0).float()
#        else:
#            h_0, c_0 = hidden
        # LSTM
        output, h = self.lstm1(x)
#        output, h = self.lstm2(output)
        output = self.fc(output)
#        print(output.shape)
        output = output[:, -1, :]
#        print(output.shape)
        return output





