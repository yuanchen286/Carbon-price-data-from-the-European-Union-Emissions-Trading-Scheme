class Config():
    data_path = 'D:/Supplementary data/Code/The proposed model/Dataset1/SVMD.xlsx'   #Change path if needed
    timestep = 1
    batch_size = 20
    feature_size = 1
    hidden_size = 128
    num_layers = 1
    output_size = 3
    epochs = 500
    learning_rate = 0.0001
    alpha = 0.4
    gamma = 0.25
