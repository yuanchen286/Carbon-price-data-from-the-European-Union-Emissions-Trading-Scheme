import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader
from Config import Config

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
config = Config()

#import data
def load_data():
    df = pd.read_excel(config.data_path)
    return df
    
class MyDataset(Dataset):
    def __init__(self, data):
        self.data = data

    def __getitem__(self, item):
        return self.data[item]

    def __len__(self):
        return len(self.data)

def nn_seq(config):
    seq_len, B, num = config.timestep, config.batch_size, config.output_size
    print('data processing...')
    dataset = load_data()
    # split
    train = dataset[:int(len(dataset) * 0.8)]
    test = dataset[int(len(dataset) * 0.8):len(dataset)]
    m, n = np.max(train[train.columns[2]]), np.min(train[train.columns[2]])

    def process(data, batch_size, step_size, shuffle):
        carbon = data[data.columns[2]]
        carbon = (carbon - n) / (m - n)  
        carbon = carbon.tolist()   
        seq = []
        for i in range(0, len(data) - seq_len - num + 1, step_size):
            train_seq = []
            train_label = []

            for j in range(i, i + seq_len):
                x = [carbon[j]]
                train_seq.append(x)    

            for j in range(i + seq_len, i + seq_len + num):
                train_label.append(carbon[j])   

            train_seq = torch.FloatTensor(train_seq)
            train_label = torch.FloatTensor(train_label).view(-1)
            seq.append((train_seq, train_label))

       
        seq = MyDataset(seq)
        seq = DataLoader(dataset=seq, batch_size=batch_size, shuffle=shuffle, num_workers=0, drop_last=False)

        return seq

    Dtr = process(train, B, step_size=1, shuffle=False)
    Dte = process(test, B, step_size=num, shuffle=False)

    return Dtr, Dte, m, n

def get_mape(x, y):
    """
    :param x:true
    :param y:pred
    :return:MAPE
    """
    return np.mean(np.abs((x - y) / x))

def get_mse(x, y):
    """
    :param x:true
    :param y:pred
    :return:MAPE
    """
    mse = np.mean((x - y)**2)
    return mse